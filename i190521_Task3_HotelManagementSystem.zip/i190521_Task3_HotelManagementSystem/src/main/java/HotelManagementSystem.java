import com.thoughtworks.qdox.model.expression.Add;

import javax.lang.model.element.Name;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Scanner;

class Guest
{
    private
    String Name;
    String Address;
    int guestKeyNumber;
    Room R;

    Guest()
    {
        Name = null;
        Address = null;
        guestKeyNumber = 0;
    }

    Guest(String name, String Address)
    {
        this.Name = name;
        this.Address = Address;

        HotelManagementSystem.Guest_KeyNo[0] = 1;
        HotelManagementSystem.Guest_Name[0] = name;
        HotelManagementSystem.Guest_Address[0] = Address;
    }

    void setName(String Name)
    {
        this.Name = Name;
    }
    String getName()
    {
        return Name;
    }


    void setAddress(String Address)
    {
        this.Address = Address;

    }
    String getAddress()
    {
        return Address;
    }

    void PrintInfo()
    {
        System.out.println();
    }


}

class Room
{
    private
    int Room_number;
    boolean status;
    int Number_of_rooms;


    Room()
    {
        Room_number = 0;
        status = false;
        Number_of_rooms = 0;
        boolean []Rooms = new boolean[Number_of_rooms];

        for(int i=0; i<Number_of_rooms; i++)
        {
            Rooms[i] = false;
        }
    }

    Room(int Number_of_rooms)
    {

        this.Number_of_rooms = Number_of_rooms;

        boolean []Rooms = new boolean[this.Number_of_rooms];

        for(int i=0; i<Number_of_rooms; i++)
        {
            Rooms[i] = false;
        }
    }

    void setRoom_number(int Room_number)
    {
        this.Room_number = Room_number;
    }
    int getRoom_number()
    {
        return Room_number;
    }

    void setRoom_Status(boolean status)
    {
        this.status = status;
    }
    boolean getRoom_Status()
    {
        return status;
    }


    void AddRooms()
    {


    }
}


class InvalidMenuNumberException  extends Exception
{
    public InvalidMenuNumberException (String str)
    {
        super(str);
    }
}

public class HotelManagementSystem
{
    static int size = 50;

    //Array for Room
    static int []Rooms = new int[size];               //0 -> no rooom in the array,  1-> room is added/avilable,
                                                      // 2-> room is reserved,  3->room is booked


    //Arrays for Guest Data
    static int []Guest_KeyNo = new int[size];
    static String []Guest_Name = new String[size];
    static String []Guest_Address = new String[size];
    static int []Guest_RoomNumber = new int[size];

    //exception
    static void validateMenu(int choice) throws InvalidMenuNumberException
    {
        if(choice < 1 || choice > 7){

            throw new InvalidMenuNumberException("Menu Number is Not Valid.");
        }
        else {
            System.out.println("Proceed Next");
        }
    }

    static int MyRoomsIntheArray=10;
    static int notAvailable=4;


    static public void AddRoom()
    {

        Rooms[MyRoomsIntheArray] = 1;               //Room is added in the array
        System.out.println("Room is added successfully.");

        MyRoomsIntheArray++;
    }

    static void getAvailableRooms()
    {
        System.out.print("Available Rooms are : ");
        int i;
        for(i=0; i<size; i++)
        {
            if(Rooms[i] == 1)
            {
                System.out.print(i+1 + " ");
                // notAvailable=0;
            }

        }

        if( i == size-1 && notAvailable == 1)
        {
            System.out.println("Sorry! No Room is Available.");
        }


    }

    static void bookRoom()
    {

        System.out.print("Available Room/s: ");
        int i;
        for(i=0; i<MyRoomsIntheArray; i++)
        {
            if(Rooms[i] == 1)
            {
                System.out.print(i+1 + " ");
                notAvailable = 0;
            }
            else
                notAvailable = 4;
        }


        if( (notAvailable == 4) )
        {
            System.out.println("Sorry! No Room is Available.");
        }

        System.out.println("\nPlease, enter a Room Number from the above Availales : ");
        int no;
        no = sc.nextInt();
        int g;
        for(g=0; g<MyRoomsIntheArray; g++)
        {
            Rooms[no-1] = 3;
            Guest_RoomNumber[i] = no-1;
        }
        System.out.println("Entered Room is booked for you successfully. ");
    }
    static Scanner sc = new Scanner(System.in);
    static void guestSearch()
    {
        int Key;
        System.out.println("Enter guest key No : ");
        Key = sc.nextInt();

        for(int i=0; i<size ; i++)
        {
            if(Key == Guest_KeyNo[i])
            {
                System.out.println("Guest Name is: " + Guest_KeyNo[i]);
                System.out.println("Guest Name is: " + Guest_Name[i]);
                System.out.println("Guest Name is: " + Guest_Address[i]);
                System.out.println("Guest Name is: " + Guest_RoomNumber[i]);
            }
        }
    }


    static void reserveRoom()
    {
        System.out.print("Available Room/s: ");
        int i;
        for(i=0; i<MyRoomsIntheArray; i++)
        {
            if(Rooms[i] == 1)
            {
                System.out.print(i+1 + " ");
                notAvailable = 0;
            }
            else
                notAvailable = 4;
        }


        if( (notAvailable == 4) )
        {
            System.out.println("Sorry! No Room is Available.");
        }

        System.out.println("\nPlease, enter a Room Number from the above Availales : ");
        int no;
        no = sc.nextInt();
        int g;
        for(g=0; g<MyRoomsIntheArray; g++)
        {
            Rooms[no-1] = 2;
        }
        System.out.println("Entered Room is reserved for you successfully. ");

    }

    public static void main(String[] args) throws InvalidMenuNumberException {

        for(int i=0; i<size; i++)
        {
            Rooms[i] = 0;
        }


        for(int i=0; i<MyRoomsIntheArray; i++)
        {
            Rooms[i] = 1;
        }


        int choice;

        Guest G = new Guest("M Umer", "Street 1, House 1 , Isb");



        int a = 10;

        do {
            System.out.println("\n\nChoose one of the following options : ");
            System.out.println("1.Add Rooms");
            System.out.println("2.Get Available Rooms");
            System.out.println("3.Search Guest");
            System.out.println("4.Book Room");
            System.out.println("5.Reserve Room");
            System.out.println("6.Exit");
            System.out.println("7.Close the System");
            System.out.print("---> ");


            choice = sc.nextInt();



            try
            {
                validateMenu(8);
            }
            catch (InvalidMenuNumberException ex)
            {
                System.out.println("Caught the exception");

                // printing the message from InvalidAgeException object
                System.out.println("Exception occured: " + ex);
            }




            if(choice == 1)
            {
               AddRoom();
            }
            else if(choice == 2)
            {
                getAvailableRooms();
            }
            else if(choice == 3)
            {
                guestSearch();
            }
            else if(choice == 4)
            {
                  bookRoom();
            }
            else if(choice == 5)
            {
                reserveRoom();
            }


        }while(choice ==1 || choice == 2 || choice ==3 || choice ==4  || choice ==5 || choice==6);


        //FILE HANDLING
        try
        {

            FileWriter myWriter = new FileWriter("HMS.txt");
            myWriter.write("Total Rooms in the Hotel : ");
            myWriter.write( MyRoomsIntheArray + "");

            myWriter.write("\nBooked Rooms :\n");
            for(int i=0; i<MyRoomsIntheArray; i++)
            {
                if(Rooms[i] == 3)
                {
                    myWriter.write(Rooms[i] + " ");
                }
            }

            myWriter.write("\nReserved Rooms :\n");
            for(int i=0; i<MyRoomsIntheArray; i++)
            {
                if(Rooms[i] == 2)
                {
                    myWriter.write(Rooms[i] + " ");
                }
            }


            myWriter.write("\nGuest/s Details :\n");
            myWriter.write(Guest_Name[0]+ "\n");
            myWriter.write(Guest_KeyNo[0]+ "\n");
            myWriter.write(Guest_Address[0]+ "\n");
            myWriter.write(Guest_RoomNumber[0]+ "\n");

            myWriter.close();

        }

        catch (IOException e)
        {
            System.out.println("An error occurred.");
            e.printStackTrace();
        }

    }
}
