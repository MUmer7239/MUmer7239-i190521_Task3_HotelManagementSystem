import org.testng.annotations.Test;
import org.testng.annotations.Test;
import static org.assertj.core.api.Assertions.assertThat;
import nl.altindag.console.ConsoleCaptor;
import org.junit.Assert;
import org.testng.annotations.Test;

import java.io.ByteArrayOutputStream;
import java.io.PrintStream;
import java.lang.reflect.Method;
import java.lang.reflect.InvocationTargetException;
import static org.junit.Assert.assertArrayEquals;
import static org.junit.Assert.assertEquals;
public class TestCases {


    @SuppressWarnings("static-access")
    @Test
    public void getAvailableRooms(){
        HotelManagementSystem H = new HotelManagementSystem();

        ByteArrayOutputStream ConsoleOutput= new ByteArrayOutputStream();
        System.setOut(new PrintStream(ConsoleOutput));
        int arr[]={1,1,1,1,1,1,1,1,1,1};                   //1 means room is added

        HotelManagementSystem.getAvailableRooms();
        assertEquals(arr ,HotelManagementSystem.Rooms);
    }



    @SuppressWarnings("static-access")
    @Test
    public void AddRoom(){
        HotelManagementSystem H = new HotelManagementSystem();

        ByteArrayOutputStream ConsoleOutput= new ByteArrayOutputStream();
        System.setOut(new PrintStream(ConsoleOutput));
        int arr[]={1,1,1,1,1,1,1,1,1,1,1};                   //1 means room is added

        HotelManagementSystem.AddRoom();
        assertEquals(arr ,HotelManagementSystem.Rooms);
    }


    @SuppressWarnings("static-access")
    @Test
    public void bookRoom(){
        HotelManagementSystem H = new HotelManagementSystem();

        ByteArrayOutputStream ConsoleOutput= new ByteArrayOutputStream();
        System.setOut(new PrintStream(ConsoleOutput));
        int arr[]={1,2,1,1,2,2,1,1,1,1,2};                   //2 means room is added

        HotelManagementSystem.bookRoom();
        assertEquals(arr ,HotelManagementSystem.Rooms);
    }


    @SuppressWarnings("static-access")
    @Test
    public void reservedRoom(){
        HotelManagementSystem H = new HotelManagementSystem();

        ByteArrayOutputStream ConsoleOutput= new ByteArrayOutputStream();
        System.setOut(new PrintStream(ConsoleOutput));
        int arr[]={3,1,1,1,1,3,1,1,3,3,1};                   //3 means room is added

        HotelManagementSystem.reserveRoom();
        assertEquals(arr ,HotelManagementSystem.Rooms);
    }


    @SuppressWarnings("static-access")
    @Test
    public void guestSearch(){
        HotelManagementSystem H = new HotelManagementSystem();

        ByteArrayOutputStream ConsoleOutput= new ByteArrayOutputStream();
        System.setOut(new PrintStream(ConsoleOutput));


        HotelManagementSystem.guestSearch();
        assertEquals("M Umer", "Street 1, House 1 , Isb" ,HotelManagementSystem.Rooms);
    }
}
